//! Internal logic for bootloader and system state manipulation.

mod statefile;
